# Zyrex Sticker Packs

Drop .webp, .png, or .jpg files into the mood folder they fit.
Zyrex picks a random file from the matching mood folder each time
it decides to send a sticker. No code changes or restart needed —
just add files and push.

Folders:
- savage/    - roast/blunt replies
- laughing/  - genuinely funny moment
- done/      - "done with this conversation" energy
- shock/     - surprised/shocked reaction
- smug/      - smug/confident reaction
- neutral/   - default/fallback, used if a mood folder is empty

If a mood folder has no files, Zyrex falls back to neutral/.
If neutral/ is also empty, no sticker is sent that turn (silent,
not an error).
